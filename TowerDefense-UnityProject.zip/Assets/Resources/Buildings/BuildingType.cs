public enum BuildingType
{
    RedTower,
    BlueTower,
    GreenTower,
    YellowTower,
    Radar,
    Factory,
    PowerPlant,
    Storage
}
