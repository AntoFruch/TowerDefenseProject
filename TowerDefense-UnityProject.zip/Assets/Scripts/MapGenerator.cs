using UnityEngine;
using System.Linq;
public class MapGenerator : MonoBehaviour
{
    public static TileType[][] map;
    private MapPrefabs mapPrefabs;

    // Instancie les tuiles au bon endroit en fonction de la map
    public void GenerateMap()
    {
        mapPrefabs = Game.Instance.mapPrefabs;
        map = Game.Instance.map;

        for (int y=0; y<map.Length; y++)
        {
         for (int x=0; x<map[0].Length; x++)
            {
                TileType type = map[y][x];
                bool[] adj = adjascentPath(x,y);

                // En fonction du type de tuile à placer, la détermination de son orientation est différente
                Quaternion rotation = Quaternion.identity;
                switch (type)
                {
                    // 2 possibilités : vers horizontal ou vertical ?
                    case TileType.PATH:
                        if (adj[0] && adj[1]) // up + down
                        {
                            rotation = Quaternion.Euler(0f, 0f, 0f);
                        } else if (adj[2] && adj[3]) // left + right
                        {
                            rotation = Quaternion.Euler(0f, 90f, 0f);
                        }

                        Instantiate(mapPrefabs.straightPath, new Vector3(x,0,y),rotation);
                        break;
                    // l'intersection est spéciale : il peut y avoir 2, 3 ou 4 chemins adjascents
                    case TileType.INTERSECTION:
                        switch (adj.Sum(b => b ? 1 : 0)) // calcul de combien d'adjascents sont true 
                        {
                            case 4: // pas de question a se poser sur l'orientation, on met le carrefour
                                Instantiate(mapPrefabs.crossPath, new Vector3(x, 0, y), rotation);
                                break;
                            case 3: // il faut mettre une intersection à 3 embranchements
                                if (adj[0] && adj[2] && adj[3]) //  up left right -> vers le haut 
                                {
                                    rotation = Quaternion.Euler(0f,0f,0f);
                                } else if (adj[1] && adj[3] && adj[0]) // down right up -> vers la droite
                                {
                                    rotation = Quaternion.Euler(0f, 90f, 0f);
                                } else if (adj[2] && adj[0] && adj[1]) // left up down -> vers la gauche
                                {
                                    rotation = Quaternion.Euler(0f, 270f, 0f);
                                } else if (adj[3] && adj[1] && adj[2]) // right down left -> vers le bas
                                {
                                    rotation = Quaternion.Euler(0f, 180f, 0f);
                                }
                                Instantiate(mapPrefabs.splitPath, new Vector3(x,0,y),rotation);
                                break;
                            case 2:
                                GameObject prefab = null;
                                if (adj[0] && adj[2] ) //  up left
                                {
                                    rotation = Quaternion.Euler(0f,0f,0f);
                                    prefab = mapPrefabs.cornerPath;
                                } else if (adj[0] && adj[3]) // up right
                                {
                                    rotation = Quaternion.Euler(0f, 90f, 0f);
                                    prefab = mapPrefabs.cornerPath;
                                } else if (adj[1] && adj[2]) // down left
                                {
                                    rotation = Quaternion.Euler(0f, -90f, 0f);
                                    prefab = mapPrefabs.cornerPath;
                                } else if (adj[1] && adj[3]) // down right
                                {
                                    rotation = Quaternion.Euler(0f,-180f, 0f); 
                                    prefab = mapPrefabs.cornerPath;
                                } else if (adj[0] && adj[1]) // up down
                                {
                                    rotation = Quaternion.Euler(0f, 0f, 0f);
                                    prefab = mapPrefabs.straightPath;
                                } else if (adj[2] && adj[3]) // left right
                                {
                                    rotation = Quaternion.Euler(0f, 90f, 0f);
                                    prefab = mapPrefabs.straightPath;
                                }
                                Instantiate(prefab, new Vector3(x,0,y),rotation); 
                                break;
                            }
                            break;
                    // les cas Spawn et End sont les mêmes, ils faut simplement determiner si la tuile est au milieu d'un chemin ou au bout
                    // le cas dans un coin n'est pas géré
                    case TileType.SPAWN or TileType.END:
                        bool end = true;
                        if (adj[0])
                        {
                            rotation = Quaternion.Euler(0f, 0f, 0f);
                            
                        } else if (adj[1])
                        {
                            rotation = Quaternion.Euler(0f, 180f, 0f);
                        } else if (adj[2])
                        {
                            rotation = Quaternion.Euler(0f, -90f, 0f);
                        } else if (adj[3])
                        {
                            rotation = Quaternion.Euler(0f, 90f, 0f);
                        }
                        
                        if (adj[0] && adj[1])
                        {
                            rotation = Quaternion.Euler(0f, 0f, 0f);
                            end = false;
                        } else if (adj[2] && adj[3])
                        {
                            rotation = Quaternion.Euler(0f, 90f, 0f);
                            end = false;
                        }
                        
                        // TYPE DE TUILE
                        if (type == TileType.SPAWN)
                        {
                            Instantiate(end ? mapPrefabs.startTileEnd : mapPrefabs.startTileStraight, new Vector3(x,0,y),rotation);
                        } else if (type == TileType.END)
                        {
                            Instantiate(end ? mapPrefabs.endTileEnd : mapPrefabs.endTileStraight, new Vector3(x,0,y),rotation);
                        }

                        break;
                    // Les cas Edge et constructibles sont triviaux
                    case TileType.EDGE:
                        Instantiate(mapPrefabs.edgeTile, new Vector3(x, 0, y), Quaternion.identity);   
                        break;
                    case TileType.CONSTRUCTIBLE:
                        Instantiate(mapPrefabs.constructibleTile, new Vector3(x, 0, y), Quaternion.identity);
                        break;
                }
            }   
        }
        // Une fois la carte générée, on ajoute des bordure avec de la génération aléatoire.
        GenerateBorders();
    }

    // retourne un array de booleens representant si les tuiles adjascentes sont des chemins valables ou pas.
    // structure de retour {up, down, left, right}
    private bool[] adjascentPath(int x, int y)
    {
        bool up = y<map.Length-1 ? 
            map[y+1][x] == TileType.PATH || map[y+1][x] == TileType.INTERSECTION || map[y+1][x] == TileType.SPAWN || map[y+1][x] == TileType.END: false;

        bool down = y>0 ? 
            map[y-1][x] == TileType.PATH || map[y-1][x] == TileType.INTERSECTION || map[y-1][x] == TileType.SPAWN || map[y-1][x] == TileType.END: false;

        bool right = x<map[0].Length-1 ? 
            map[y][x+1] == TileType.PATH || map[y][x+1] == TileType.INTERSECTION || map[y][x+1] == TileType.SPAWN || map[y][x+1] == TileType.END: false;

        bool left = x>0 ? 
            map[y][x-1] == TileType.PATH || map[y][x-1] == TileType.INTERSECTION || map[y][x-1] == TileType.SPAWN || map[y][x-1] == TileType.END: false;

        return new bool[]
        {
            up, down, left, right
        };
    }

    public int borderSize = 30; // combien de tuiles autour de la map
    public GameObject[] borderPrefabs; // arbres, rochers, etc.

    public void GenerateBorders()
    {
        int mapWidth = map[0].Length;
        int mapHeight = map.Length;

        // On boucle sur toute la zone étendue
        for (int y = -borderSize; y < mapHeight + borderSize; y++)
        {
            for (int x = -borderSize; x < mapWidth + borderSize; x++)
            {
                // On skip les tuiles déjà utilisées dans la map
                if (x >= 0 && x < mapWidth && y >= 0 && y < mapHeight)
                    continue;

                // Position pour instancier
                Vector3 pos = new Vector3(x, 0, y);

                if (Random.value < 0.3f)
                {
                    float random = Random.value;
                    if (random < 1/3f)
                    {
                        Instantiate(mapPrefabs.singleTree, pos, Quaternion.identity);
                    } else if (random < 2/3f)
                    {
                        Instantiate(mapPrefabs.duoTrees, pos, Quaternion.identity);
                    } else 
                    {
                        Instantiate(mapPrefabs.quadTrees, pos, Quaternion.identity);
                    }
                } else
                {
                    float random = Random.value;
                    if (random < 0.7f)
                    {
                        Instantiate(mapPrefabs.constructibleTile, pos, Quaternion.identity);
                    } else if (random < 0.85f)
                    {
                        Instantiate(mapPrefabs.hill, pos, Quaternion.identity);
                    } else
                    {
                        Instantiate(mapPrefabs.crystals, pos, Quaternion.identity);

                    }
                }
            }
        }
    }

    
}
